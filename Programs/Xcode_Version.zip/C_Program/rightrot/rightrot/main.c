//
//  main.c
//  rightrot
//
//  Created by 钟宜江 on 2021/8/24.
//

#include <stdio.h>

int maxbits() {
    unsigned int x, y;
    y = 0;
    x = (unsigned) ~0;
    while (x != 1) {
        y += 1;
        x = (x >> 1);
    }
    return y+1;
}

unsigned rightrot(unsigned x, int n) {
    int c;
    
    c = maxbits();
    // (x & ~(~0 << n)) /* 先获取x右端的n位 */
    // (x & ~(~0 << n)) << (c-n) /* 将获取的n位左移到左端 */
    // x >> n /* 将x右移n位 */
    // (x >> n)|((x & ~(~0 << n)) << (c-n)); /* 通过或｜来组合起来 */
    return (x >> n)|((x & ~(~0 << n)) << (c - n));
}

int main() {
    // insert code here...
    printf("%d\n", rightrot(12, 2));
    return 0;
}

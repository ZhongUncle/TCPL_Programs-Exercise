//
//  main.c
//  itoa
//
//  Created by 钟宜江 on 2021/8/30.
//

#include <stdio.h>
#include <string.h>
#define MAXLINE 1000

void itoa(int n, char s[]);
void reverse(char s[]);

int main() {
    int i = 0;
    char a[MAXLINE] = "13";
        
    itoa(i, a);
    printf("%s \n", a);
    return 0;
}

/* itoa: convert n to characters in s */
void itoa(int n, char s[]) {
    int i, sign;
    
    if ((sign = n) < 0) /* record sign */
        n = -n - 1;
    i = 0;
    do {
        s[i++] = n % 10 + '0';
    }while ((n /= 10) > 0);
    if (sign < 0){
        s[i] += 1;
        i++;
        s[i] = '-';
    }
    s[i] = '\0';
    reverse(s);
}

/* reverse: reverse string s in place */
void reverse(char s[])
{
    int c, i;
    unsigned long j;
    
    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

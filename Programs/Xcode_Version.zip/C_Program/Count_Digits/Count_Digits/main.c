//
//  main.c
//  Count_Digits
//
//  Created by 钟宜江 on 2021/7/9.
//

/* 统计字符（包括空格、标点和转义字符） */
#include <stdio.h>

///* count digits, white space, other*/
//main() {
//    int c, i, nwhite, nother;
//    int ndigit[10];             /* 定义一个十位的数组 */
//
//    nwhite = nother = 0;
//    for (i = 0; i < 10; ++i)
//        ndigit[i] = 0;
//
//    while ((c = getchar()) != EOF)
//        if (c >= '0' && c <= '9')
//            ++ndigit[c-'0'];
//        else if (c == ' ' || c == '\n' || c == '\t')
//            ++nwhite;
//        else
//            ++nother;
//
//    printf("digits =");
//    for (i = 0; i < 10; ++i)
//        printf(" %d", ndigit[i]);
//    printf(",white space = %d, other = %d\n", nwhite, nother);
//}

/* Exercise 1-13 */
///* 水平的柱状图的柱*/
//main() {
//    int a;
//    int i;
//
//    /* a表示柱子有多长 */
//    a = 5;
//
//    /* 生成柱子 */
//    for (i = 0; i < a; i++)
//        printf("\043");
//    printf("\n");
//}

/* Exercise 1-14 */
/* 垂直的柱状图*/
main() {
    int arr[3];
    int i, j;
    int ln;     /* 最多多少行*/
    int vn;     /* 数组有多少元素————有多少列 */

    /* a, b, c表示每个柱子有多长 */
    arr[0] = 2;
    arr[1] = 5;
    arr[2] = 4;
    /* 柱子长度的上限 */
    ln = 6;
    vn = 3;
    

    /* 生成柱状图 */
    for (i = 0; i <= ln; ++i) {
        /* 生成每列 */
        for (j = 0; j < vn; ++j) {
            if (arr[j] < (ln-i)) {
                printf(" \t");
            }else{
                printf("\043\t");
            }
        }
        printf("\n");
    }
}

//
//  main.c
//  expand
//
//  Created by 钟宜江 on 2021/8/30.
//

#include <stdio.h>

char expand(char s1[], char s2[]){
    int i, j;
    char a, b;
    int m;
    
    i = j =0;
    
    while (s1[i] != '\0') {
        if (s1[i] == '-') {
            a = s1[i-1];
            b = s1[i+1];
            //减1来避免预先获取“-”左边的字符,放在这里避免下面的时候遇上第二个就是“-”的情况
            j -= 1;
            for (m = a; m <= b; m++, j++){
                s2[j] = m;
            }
            i += 2;
        }else{
            s2[j] = s1[i];
            i++;
            j++;
        }
    }
    return *s2;
}

int main() {
    char s1[100] = "-b-c-d";
    char s2[100] = "";
    expand(s1, s2);
    printf("%s \n", s2);
    return 0;
}

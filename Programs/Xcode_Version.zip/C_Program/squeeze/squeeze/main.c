//
//  main.c
//  squeeze
//
//  Created by 钟宜江 on 2021/8/2.
//

#include <stdio.h>

void squeeze(char s1[], char s2[])
{
    int i, j, m, r;

    for (i = j = 0; s1[i] != '\0'; i++) {
        r = 0;
        m = 0;
        while (s2[m] != '\0') {
            if (s1[i] == s2[m]) {
                r = 1;
            }
            m++;
        }
        if (r != 1){
            s1[j++] = s1[i];
        }
    }
    s1[j] = '\0';
}

int main() {
    char a[100] = "abcdfglsuiagdfjhdgsfgweiufiasi";
    char b[100] = "abcd";
    
    squeeze(a, b);
    // insert code here...
    printf("%s\n", a);
    return 0;
}



//
//  main.c
//  Line_Count
//
//  Created by 钟宜江 on 2021/7/9.
//

#include <stdio.h>

///* count lines in input */
//main() {
//    int c, nl;
//
//    nl = 0;
//    while ((c = getchar()) != EOF)
//        /* 被单引号包起来的字符表示一个整数值，称为字符常量（character constant或者称为string constant），这个整数值等于这个字符在机器字符集中的数值（就是ACSII对应值） */
//        /* 转义字符（escape sequence）被用在字符常量也是可以的 */
//        if (c == '\n')
//            /* 这里因为只有一个声明，所以就省略了大括号 */
//            ++nl;
//    printf("%d'\n'", nl);
//}


//
//  main.c
//  htoi
//
//  Created by 钟宜江 on 2021/7/31.
//

#include <stdio.h>
#define MAXLINE 1000

int main() {
    char a[MAXLINE] = "0X1fd";               /* 假设这就是输入的是十六进制字符串 */
//    int b[MAXLINE];
    int lowerIndex = 0;                   /* 小写化的时候使用的下标 */
    int i = 0;
//    int l = 0;
//    int c = 0;
//    int num = 0;
    int hex = 0;

    /* 将输入的十六进制字符串全部小写 */
    while (lowerIndex<=MAXLINE) {
        if (a[lowerIndex] >= 'A' && a[lowerIndex] <= 'Z')
            a[lowerIndex] = a[lowerIndex] + 'a' - 'A';
        else
            a[lowerIndex] = a[lowerIndex];
        lowerIndex = lowerIndex + 1;
    }
    
    while (i<=MAXLINE) {
         if (a[i] == 'x') {                               /* 由于全部小写了，所以不用考虑大写X的情况 */
             hex = (a[i+1] - '0')*16;
             if (a[i+2] >= '0' && a[i+2] <= '9') {
                 hex = hex + a[i+2];
                 printf("%d", hex);
             }else if (a[i+2] >= 'a' && a[i+2] <= 'z') {
                 hex = hex + a[i+2] - 'W';                /* 十六进制的字母转换成数字，大写字母转换的话减'7' */
                 printf("%d\n", hex);
             }

        }
        i = i + 1;
    }

    //    while (i<=13) {
    //            if (a[i] == 'x' && l == 1) {
    //                b[l] = 0;
    //                l = l + 1;
    //                /* 不是第一个十六进制数的x，或者非数字非合规字母，需要在这里将之前的数算出来 */
    //            }else if ((a[i] == 'x' && l != 0) || a[i] <= '0'){
    ////                while (c<l) {
    ////
    ////                    c = c + 1;
    ////                }
    //                num = b[0];
    //                printf("%d", num);
    //                l = 1;
    //                b[l] = 0;
    //            }else if (a[i] >= '0' && a[i] <= '9') {
    //                b[l] = a[i] - '0';
    //                l = l + 1;
    //            }else if (a[i] >= 'a' && a[i] <= 'z') {
    //                b[l] = a[i] - 'W';                /* 十六进制的字母转换成数字，大写字母转换的话减'7' */
    //                l = l + 1;
    //            }
    //
    //
    //        i = i + 1;
    //    }
    printf("\n%s \n", a);
    return 0;
}



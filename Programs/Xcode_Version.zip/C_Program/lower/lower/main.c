//
//  main.c
//  lower
//
//  Created by 钟宜江 on 2021/8/27.
//

#include <stdio.h>

int lower(int c)
{
    int r;
    
    r = (c >= 'A' && c <= 'Z') ? c + 'a' - 'A' : c;
    
    return r;
}

int main() {
    //这里记得改成%c哦，不要因为是int类型就用%d
    printf("%c \n",lower('D'));
    return 0;
}

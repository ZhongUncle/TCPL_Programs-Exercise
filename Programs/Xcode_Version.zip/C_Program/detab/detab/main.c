//
//  main.c
//  detab
//
//  Created by 钟宜江 on 2021/7/12.
//

/* Exercise 1-20: dettab */
/* 问题1 */
#include <stdio.h>

main() {
    char c;
    int spaceCount;

    c = getchar();
    
    while (c != '\n') {
        if (c == '\t') {
            spaceCount = 0;
            while (spaceCount != 3) {
                c = '\040';
                spaceCount = spaceCount + 1;
            }
        }
    }
    putchar(c);
}

/* 问题2：n是symbolic parameter */

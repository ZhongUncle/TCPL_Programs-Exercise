//
//  main.c
//  RemoveComments
//
//  Created by 钟宜江 on 2021/8/17.
//

#include <stdio.h>

int main() {
    char c;
    int a;

    a=4;

    while ((c= getchar()) != EOF) {
        //遇到斜杠：考虑是/* */的开头还是结尾或者是//的哪一个
        if (c == '/'){
            //还没有遇到过斜杠，将a变成2
            if (a == 4){
                a = 3;
                continue;
                //已经遇到过一个斜杠了，但是并没有遇到星号，直接将其变成1.这就是//的情况
            }else if (a == 3){
                a = 1;
                continue;
                //遇到过一个斜杠和两个星号
            }else if (a == 2){
                a = 4;
            }
        }else if (c == '*') {
            //已经遇到过一个斜杠了，但是还没有遇到星号，将a设定成0，直到出现*/才能再次正常输出。这就是/*的情况
            if (a == 3){
                a = 0;
                continue;
                //已经遇到过一个斜杠和一个星号，将其还原成2，待下一个斜杠将其变成3
            }else if (a == 0){
                a = 2;
                continue;
            }
        }else if (c == '\n' && a == 1){
            //遇到换行符
            a = 4;
        }else if (a > 1) {
            //正常情况：保持a=4并且输出当前获取字符
            a = 4;
            putchar(c);
        }else{
            //如果a<4就直接跳过输入的任何字符
            continue;
        }
    }
    return 0;
}

//#include <stdio.h>
//
//int main() {
//
//    /* 1是记录，0是不记录 */
//    printf("Hello, World\n")
//    return 0;
//}

////wqeqe

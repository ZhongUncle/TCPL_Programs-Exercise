//
//  main.c
//  CountChar
//
//  Created by 钟宜江 on 2021/7/8.
//

#include <stdio.h>

/* count characters in input; 1st version */
main() {
    long nc;

    nc = 0;
    while (getchar() != EOF)
//    while (getchar() != '\n')
        ++nc;
    printf("%ld\n",nc);
}

///* count characters in input; 2nd version */
//main() {
//    double nc;
//
//    for (nc = 0; getchar() != EOF; ++nc)
//        /* 单独的分号表示for的body，这种被称为null statement（空声明）——c语言的语法要求for必须有body */
//        ;
//    printf("%.0f\n",nc);
//}



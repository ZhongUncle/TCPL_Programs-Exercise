//
//  main.c
//  inverts
//
//  Created by 钟宜江 on 2021/8/23.
//

#include <stdio.h>

unsigned invert(unsigned x, int p, int n) {
    
    return (x^(~(~0 << n) << (p+1-n)));
}

int main() {
    //
    // insert code here...
    printf("%d \n", invert(14, 0, 1));
    return 0;
}



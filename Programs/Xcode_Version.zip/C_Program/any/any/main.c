//
//  main.c
//  any
//
//  Created by 钟宜江 on 2021/8/22.
//

#include <stdio.h>

int any(char s1[], char s2[]){
    int i, j;
    int m;
    int r;
    
    j = -1;
    
    for (i = 0; s1[i] != '\0'; i++){
        for (m = 0; s2[m] != '\0'; m++) {
            if (s1[i] == s2[m]) {
                j = i;
                break;
            }
        }
        if (j >= 0){
            break;
        }
    }
    if (j >= 0){
        r = j;
    }else{
        r = -1;
    }
    return r;
}

int main() {
    char a[100] = "123abcdefghijk";
    char b[100] = "abcd";
    printf("%d \n", any(a, b));
    return any(a, b);
}

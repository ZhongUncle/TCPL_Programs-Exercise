//
//  main.c
//  HelloWorld
//
//  Created by 钟宜江 on 2021/7/7.
//

//include information about standard library
//包含标准库的信息
#include <stdio.h>

//define a function named main that receives no argument values
//定义一个函数，名为main，没有获得任何参数值
int main() {
    //statements of main are enclosed in braces
    //main的声明被大括号包裹
    
    //main calls library function printf to print this sequence of characters;\n represents the newline character
    //main调用库函数printf来打印这个字符串；\n表示新的一行字符
    printf("Hello, \bWorld!\t");
    printf("world");
    printf("\n");
}

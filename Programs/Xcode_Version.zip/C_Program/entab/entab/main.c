//
//  main.c
//  entab
//
//  Created by 钟宜江 on 2021/8/13.
//

#include <stdio.h>
#define TABSIZE 4

main() {
    char str[100], outStr[100];
    char c;
    int i, j;
    int spaceCount;

    spaceCount = 0;
    i = 0;
    j = 0;
    c = str[i];
    
    while (c == '\n') {
        if (c == ' ') {
            ++spaceCount;
            ++i;
        }else{
            if (spaceCount == TABSIZE) {
                spaceCount = 0;
                outStr[j] = '\t';
                j += 1;
                ++i;
            }else if (spaceCount != 0 && spaceCount != TABSIZE){
                for (i = 0; i < spaceCount; ++i) {
                    //给字符串添加空格
                    outStr[j] = ' ';
                    j += 1;
                    ++i;
                }
            }
            outStr[j] = str[i];
            j += 1;
            ++i;
        }
        
    }
}

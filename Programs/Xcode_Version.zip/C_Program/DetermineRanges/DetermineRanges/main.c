//
//  main.c
//  DetermineRanges
//
//  Created by 钟宜江 on 2021/7/25.
//

#include <stdio.h>
//#include <limits.h>
///* 通过标准头文件打印出范围 */
///* Xcode中，limits.h在i386目录下，而不是直接显示的limits.h */
//int main() {
//    /* char */
//    printf("无符号的char最大值：%d \n", UCHAR_MAX);
//    printf("有符号的char最大值：%d \n", SCHAR_MAX);
//    printf("有符号的char最小值：%d \n", SCHAR_MIN);
//
//    /* short */
//    printf("无符号的short最大值：%d \n", USHRT_MAX);
//    printf("有符号的short最大值：%d \n", SHRT_MAX);
//    printf("有符号的short最小值：%d \n", SHRT_MIN);
//
//    /* int */
//    printf("无符号的int最大值：%u \n", UINT_MAX);
//    printf("有符号的int最大值：%u \n", INT_MAX);
//    printf("有符号的int最小值：%u \n", INT_MIN);
//
//    /* long */
//    printf("无符号的long最大值：%lu \n", ULONG_MAX);
//    printf("有符号的long最大值：%lu \n", LONG_MAX);
//    printf("有符号的long最小值：%lu \n", LONG_MIN);
//    return 0;
//}

int main() {
    /* char */
    printf("无符号的char最大值：%d \n", (unsigned char) ~0);
    printf("无符号的char最小值：%d \n", (unsigned char) 0);
    printf("有符号的char最大值：%d \n", (unsigned char) ~0 >> 1);
    printf("有符号的char最大值：%d \n", -(unsigned char) ~0 >> 1);

    /* short */
    printf("无符号的short最大值：%d \n", (unsigned short) ~0);
    printf("无符号的short最小值：%d \n", (unsigned short) 0);
    printf("有符号的short最大值：%d \n", (unsigned short) ~0 >> 1);
    printf("有符号的short最小值：%d \n", -(unsigned short) ~0 >> 1);

    /* int */
    printf("无符号的int最大值：%u \n", (unsigned int) ~0);
    printf("无符号的int最小值：%d \n", (unsigned int) 0);
    printf("有符号的int最大值：%d \n", (unsigned int) ~0 >> 1);
    printf("有符号的int最小值：%d \n", -((unsigned int) ~0 >> 1) -1);

    /* long */
    printf("无符号的long最大值：%lu \n", (unsigned long) ~0);
    printf("无符号的long最大值：%lu \n", (unsigned long) 0);
    printf("有符号的long最大值：%ld \n", (unsigned long) ~0 >> 1);
    printf("有符号的long最小值：%ld \n", -((unsigned long) ~0 >> 1) -1);
    return 0;
}

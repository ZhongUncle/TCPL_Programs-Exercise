//
//  main.c
//  Exercise2-2
//
//  Created by 钟宜江 on 2021/7/26.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    for (i=0; i<lim-1 && (c=getchar()) != '\n' && c != EOF; ++i)
//        s[i] = c;
    
    /* 成不带关系操作符的 */
//    for (i=0; i<lim-1) {
//        for((c=getchar()) != '\n') {
//            for(c != EOF; ++i) {
//                s[i] = c;
//            }
//        }
//    }
                                               
    printf("Hello, World!\n");
    return 0;
}

//
//  main.c
//  foldLine
//
//  Created by 钟宜江 on 2021/8/14.
//

#include <stdio.h>
#include <string.h>

int main() {
    char str[100] = "The quick brown fox jumped over the lazy dog.";
    int l;
    int c, i;
    
    l = strlen(str)-1;
    c = 15;
    
    while (c<=l) {
        for (i=c; i>=c-15; i--) {
            if (str[i] == ' '){
                str[i] = '\n';
                //一旦获取到倒数第一个空格，退出for循环
                break;
            }
        }
        c += 15;
    }
    printf("%s\n", str);
}

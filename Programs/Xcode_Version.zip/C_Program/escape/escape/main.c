//
//  main.c
//  escape
//
//  Created by 钟宜江 on 2021/8/29.
//

#include <stdio.h>
//如果要把需要引用的函数写下面，就要在前面声明一下。
char escape(char s[], char t[]);
char reEscape(char a [], char t[]);

int main() {
    char s[100];
    char a[100];
    
    escape(s, "adasdad\ndassad");
    printf("adasdad\ndassad\n");
    printf("%s \n", s);
    reEscape(a, "adasdad\\ndassad\n");
    printf("%s \n", a);
    return 0;
}

char escape(char s[], char t[]) {
    int i, j;
    
    i = j = 0;
    while (t[j] != '\0') {
        switch (t[j]) {
            case '\t':
                s[i] = '\\';
                i++;
                s[i] = 't';
                break;
            case '\n':
                s[i] = '\\';
                i++;
                s[i] = 'n';
                break;
            default:
                s[i] = t[j];
                break;
        }
        i++;
        j++;
    }
    s[j] = '\0';
    return *s;
}

char reEscape(char a[], char s[]) {
    int i, j;
    
    i = j = 0;
    while (s[j] != '\0') {
        switch (s[j]) {
            case '\\':
                j++;
                switch (s[j]) {
                    case 't':
                        a[i] = '\t';
                        i++;
                        break;
                    case 'n':
                        a[i] = '\n';
                        i++;
                        break;
                }
                break;
            default:
                a[i] = s[j];
                i++;
                j++;
                break;
        }
        
    }
    a[j] = '\0';
    return *a;
}
